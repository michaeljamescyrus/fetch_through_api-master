package com.taskgiven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Taskgiven4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
